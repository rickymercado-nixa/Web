from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import mysql.connector
from tkinter import messagebox

def conn():
    try:
        db = mysql.connector.connect(host = "localhost", user = "root", password = "", database = "farm_animal")
        return db
    except mysql.connector.Error as e:
        messagebox.showerror("Database Connection", f"Failed to Connect Database: {e}")
        return None

def register_form():
    for widget in window.winfo_children():
        widget.destroy()
    
    title = Label(window,text = 'Feeding Animal Guide App',font = ('Helvetica', 20),bg="#D9D9D9")
    title.pack()

    title = Label(window,text = 'Register Account',font = ('Helvetica', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=100)

    title = Label(window,text = 'Username:',font = ('Helvetica', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=150)

    title = Label(window,text = 'Password:',font = ('Helvetica', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=225)

    title = Label(window,text = 'Email:',font = ('Helvetica', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=300)

    title = Label(window,text = 'Already have an account?',font = ('Helvetica', 12, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=425)

    label = Label(window,image = photo,bg="#D9D9D9")
    label.place(x=100,y=100)

    username_entry = Entry(window,font = ('Helvetica', 14))
    username_entry.place(x=650,y=175)

    password_entry = Entry(window,font = ('Helvetica', 14))
    password_entry.config(show='*')
    password_entry.place(x=650,y=250)

    email_entry = Entry(window,font = ('Helvetica', 14))
    email_entry.place(x=650,y=325)
    
    def registers():
        db = conn()
        if db is None:
            return
        
        cursor = db.cursor()
        
        username = username_entry.get()
        password = password_entry.get()
        email = email_entry.get()
    
        if not all([username, password, email]):
            messagebox.showerror("Error", "All fields are required!")
            return
        try:
            cursor = db.cursor()
            cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
            if cursor.fetchone():
                messagebox.showerror("Error", "Username already exist!")
                return
            cursor.execute("INSERT INTO users (username, password, email) VALUES (%s, %s, %s)", (username, password, email))
            db.commit()
            messagebox.showinfo("SUCCESS", "Register Successfully")
            logins()
        except mysql.connector.Error as e:
            messagebox.showerror("DB Error:", str(e))
            return
        finally:
            cursor.close()
            db.close()
        
    button = Button(window,font = ('Helvetica', 14),bg = '#14AE5C',text = 'Create Account',command = registers)
    button.place(x=650,y=375)

    button = Button(window,font = ('Helvetica', 14),bg = '#14AE5C',text = 'Login',command = logins)
    button.place(x=855,y=420)


def logins():
    for widget in window.winfo_children():
        widget.destroy()
        
    title = Label(window,text = 'Feeding Animal Guide App',font = ('Helvetica', 20),bg="#D9D9D9")
    title.pack()

    title = Label(window,text = 'Login Account',font = ('Helvetica', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=100)

    title = Label(window,text = 'Username:',font = ('Helvetica', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=150)

    title = Label(window,text = 'Password:',font = ('Helvetica', 14, 'bold'), bg="#D9D9D9")
    title.place(x=650,y=225)

    title = Label(window,text = "Don't have account?",font = ('Helvetica', 12, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=360)

    label = Label(window,image = photo,bg="#D9D9D9")
    label.place(x=100,y=100)

    username_entry = Entry(window,font = ('Helvetica', 14))
    username_entry.place(x=650,y=175)

    password_entry = Entry(window,font = ('Helvetica', 14))
    password_entry.config(show='*')
    password_entry.place(x=650,y=250)
    
    def login():
        db = conn()
        if db is None:
            return
        username = username_entry.get()
        password = password_entry.get()
        
        try:
            cursor = db.cursor()
            cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
            if cursor.fetchone():
                messagebox.showinfo("SUCCESS", "Login Successfully")
                dashboard()
            else:
                messagebox.showerror("ERROR", "Invalid Username or Passowrd! Please try again!")
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error: ", str(e))
        finally:
            cursor.close()
            db.close()

    button = Button(window,font = ('Helvetica', 14),bg = '#14AE5C',text = 'Login',command = login)
    button.place(x=650,y=300)

    button = Button(window,font = ('Helvetica', 14),bg = '#14AE5C',text = 'Register',command = register_form)
    button.place(x=820,y=350)
    
def cost_analysis(main):
    animals = ['Dinosaur', 'Pig', 'Chicken', 'Cow']
    cost = [600, 500, 700, 900]
    
    fig, graph=plt.subplots(figsize=(5,4))
    graph.bar(animals, cost, color = 'red')
    graph.set_title('Monthly Cost Analysis')
    graph.set_xlabel('Animals')
    graph.set_ylabel('Cost')
    
    canvas = FigureCanvasTkAgg(fig, master=main)
    canvas.draw()
    bar_graph = canvas.get_tk_widget()
    bar_graph.place(x=150,y=50)
    
    
def dashboard():
    for widget in window.winfo_children():
        widget.destroy()
        
    button = Button(window, image=bell_icon, command=notification)
    button.place(x=970, y=10)
        
    sidebar = Frame(window, bg='#7A6961', width = 200, height = 600)
    sidebar.pack(side=LEFT,fill=Y)
    
    button = Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=dashboard)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=add_animals)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=add_inventory)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=feeding_log)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=scheduling)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=logins)
    button.pack(fill=X, pady=10, padx=10)
    
    main = Frame(window, width = 700, height = 600, bg='#D9D9D9')
    label = Label(window, text='Farm Animal Feeding Guide', font=('Helvetica', 20), bg='#D9D9D9')
    label.pack()
    
    button = Button(window, text='Generate Reports', font=('Helvetica', 14))
    button.place(x=200,y=50)
    
    main.pack()
    
    cost_analysis(main)

def add_animals():
    for widget in window.winfo_children():
        widget.destroy()

    button = Button(window, image=bell_icon, command=notification)
    button.place(x=970, y=10)

    sidebar = Frame(window, bg='#7A6961', width=200, height=600)
    sidebar.pack(side=LEFT, fill=Y)

    Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=dashboard).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=add_animals).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=add_inventory).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=feeding_log).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=scheduling).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=logins).pack(fill=X, pady=10, padx=10)

    main = Frame(window, width=700, height=600, bg='#D9D9D9')
    Label(window, text='Farm Animal Feeding Guide', font=('Helvetica', 20), bg='#D9D9D9').pack()

    Label(window, text='Add Animal:', font=('Helvetica', 14), bg='#D9D9D9').place(x=200, y=120)
    animal_entry = Entry(window, font=('Helvetica', 14))
    animal_entry.place(x=200, y=150)

    Label(window, text='Add Feeding Instruction:', font=('Helvetica', 14), bg='#D9D9D9').place(x=200, y=190)
    instruction_textarea = Text(window, font=('Helvetica', 14), width=20, height=8)
    instruction_textarea.place(x=200, y=220)

    Label(window, text='Search Animal:', font=('Helvetica', 14), bg='#D9D9D9').place(x=500, y=150)
    search_bar = Entry(window, font=('Helvetica', 14))
    search_bar.place(x=630, y=150)

    headings = ("Number", "Animals", "Feeding Instructions")
    table = ttk.Treeview(window, columns=headings, show="headings", height=5)

    for col in headings:
        table.heading(col, text=col)
        table.column(col, anchor='center', width=150)

    def animal_table(filter_keyword=None):
        db = conn()
        if db is None:
            return
        cursor = db.cursor()
        table.delete(*table.get_children())
        query = "SELECT animal_id, animal_name, animal_instruction FROM animals"
        params = ()
        if filter_keyword:
            query += " WHERE animal_name LIKE %s"
            params = ("%" + filter_keyword + "%",)
        cursor.execute(query, params)
        for row in cursor.fetchall():
            table.insert("", END, values=row)
        db.close()

    def add_animal():
        animal_name = animal_entry.get().strip()
        animal_instruction = instruction_textarea.get("1.0", END).strip()
        if not animal_name or not animal_instruction:
            messagebox.showerror("Error", "Please fill in both fields.")
            return

        db = conn()
        if db is None:
            return
        try:
            cursor = db.cursor()
            cursor.execute("INSERT INTO animals (animal_name, animal_instruction) VALUES (%s, %s)", (animal_name, animal_instruction))
            db.commit()
            messagebox.showinfo("Success", "Animal added successfully.")
            animal_entry.delete(0, END)
            instruction_textarea.delete("1.0", END)
            animal_table()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))
        finally:
            db.close()


    def on_table_select(event):
        selected = table.focus()
        if not selected:
            return
        values = table.item(selected, "values")
        animal_entry.delete(0, END)
        animal_entry.insert(0, values[1])
        instruction_textarea.delete("1.0", END)
        instruction_textarea.insert("1.0", values[2])

    table.bind("<<TreeviewSelect>>", on_table_select)

    def update_animal():
        selected = table.focus()
        if not selected:
            messagebox.showwarning("Warning", "Please select an animal to update.")
            return
        values = table.item(selected, "values")
        animal_id = values[0]
        new_name = animal_entry.get().strip()
        new_instruction = instruction_textarea.get("1.0", END).strip()
        if not new_name or not new_instruction:
            messagebox.showerror("Error", "Both fields are required.")
            return

        db = conn()
        if db is None:
            return
        try:
            cursor = db.cursor()
            cursor.execute("UPDATE animals SET animal_name = %s, animal_instruction = %s WHERE animal_id = %s",
                           (new_name, new_instruction, animal_id))
            db.commit()
            messagebox.showinfo("Success", "Animal updated successfully.")
            animal_table()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))
        finally:
            db.close()

    def delete_animal():
        selected = table.focus()
        if not selected:
            messagebox.showwarning("Warning", "Please select an animal to delete.")
            return
        values = table.item(selected, "values")
        animal_id = values[0]

        if not messagebox.askyesno("Confirm", "Are you sure you want to delete this animal?"):
            return

        db = conn()
        if db is None:
            return
        try:
            cursor = db.cursor()
            cursor.execute("DELETE FROM animals WHERE animal_id = %s", (animal_id,))
            db.commit()
            messagebox.showinfo("Deleted", "Animal deleted successfully.")
            animal_table()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))
        finally:
            db.close()

    def on_search(event):
        keyword = search_bar.get().strip()
        animal_table(filter_keyword=keyword)

    search_bar.bind("<KeyRelease>", on_search)

    animal_table()
    table.place(x=500, y=190)

    Button(window, text='Add Animal', font=('Helvetica', 14), bg='#14AE5C', command=add_animal).place(x=200, y=420)
    Button(window, text='Update Animal', font=('Helvetica', 14), bg='#2196F3', command=update_animal).place(x=330, y=420)
    Button(window, text='Delete Animal', font=('Helvetica', 14), bg='#F44336', command=delete_animal).place(x=480, y=420)

    main.pack()

def add_inventory():
    for widget in window.winfo_children():
        widget.destroy()

    db = conn()
    if db is None:
        return
    cursor = db.cursor()

    cursor.execute("SELECT animal_id, animal_name FROM animals")
    animal_records = cursor.fetchall()
    animals = {name: aid for aid, name in animal_records}
    animal_names = list(animals.keys())

    def clear_fields():
        select_animals.set("Select Animals:")
        feed_entry.delete(0, END)
        weight_entry.delete(0, END)
        cost_entry.delete(0, END)

    def refresh_table(query="SELECT inventory.inventory_id, animals.animal_name, inventory.feed_name, inventory.feed_weight, inventory.feed_cost FROM inventory JOIN animals ON inventory.animal_id = animals.animal_id"):
        for row in table.get_children():
            table.delete(row)
        cursor.execute(query)
        rows = cursor.fetchall()
        for row in rows:
            table.insert("", END, iid=row[0], values=row[1:])

    def add_entry():
        animal_name = select_animals.get()
        feed = feed_entry.get()
        weight = weight_entry.get()
        cost = cost_entry.get()

        animal_id = animals.get(animal_name)

        if animal_name == "Select Animals:" or not animal_id or not feed or not weight or not cost:
            messagebox.showerror("Error", "Please fill all fields with valid values.")
            return

        try:
            cursor.execute("INSERT INTO inventory (animal_id, feed_name, feed_cost, feed_weight,) VALUES (%s, %s, %s, %s)",
                           (animal_id, feed, cost, weight))
            db.commit()
            messagebox.showinfo("Success", "Inventory added successfully.")
            refresh_table()
            clear_fields()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def on_row_select(event):
        selected = table.selection()
        if selected:
            iid = selected[0]
            cursor.execute("SELECT inventory.*, animals.animal_name FROM inventory JOIN animals ON inventory.animal_id = animals.animal_id WHERE inventory.inventory_id=%s", (iid,))
            row = cursor.fetchone()
            if row:
                select_animals.set(row[-1])
                feed_entry.delete(0, END)
                feed_entry.insert(0, row[2])
                weight_entry.delete(0, END)
                weight_entry.insert(0, row[4])
                cost_entry.delete(0, END)
                cost_entry.insert(0, row[3]) 

    def update_entry():
        selected = table.selection()
        if not selected:
            messagebox.showerror("Error", "Select an entry to update.")
            return
        iid = selected[0]
        animal_name = select_animals.get()
        feed = feed_entry.get()
        weight = weight_entry.get()
        cost = cost_entry.get()
        animal_id = animals.get(animal_name)

        if animal_name == "Select Animals:" or not animal_id or not feed or not weight or not cost:
            messagebox.showerror("Error", "Please fill all fields with valid values.")
            return

        try:
            cursor.execute("UPDATE inventory SET animal_id=%s, feed_name=%s, feed_weight=%s, feed_cost=%s WHERE inventory_id=%s",
                           (animal_id, feed, weight, cost, iid))
            db.commit()
            messagebox.showinfo("Success", "Inventory updated successfully.")
            refresh_table()
            clear_fields()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def delete_entry():
        selected = table.selection()
        if not selected:
            messagebox.showerror("Error", "Select an entry to delete.")
            return
        iid = selected[0]
        try:
            cursor.execute("DELETE FROM inventory WHERE inventory_id=%s", (iid,))
            db.commit()
            messagebox.showinfo("Deleted", "Inventory deleted successfully.")
            refresh_table()
            clear_fields()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def apply_filter(event=None):
        val = filter_inventory.get()
        base_query = "SELECT inventory.inventory_id, animals.animal_name, inventory.feed_name, inventory.feed_weight, inventory.feed_cost FROM inventory JOIN animals ON inventory.animal_id = animals.animal_id"
        if val == "Cost Ascending":
            refresh_table(base_query + " ORDER BY inventory.cost ASC")
        elif val == "Cost Descending":
            refresh_table(base_query + " ORDER BY inventory.cost DESC")
        elif val == "A-Z":
            refresh_table(base_query + " ORDER BY animals.animal_name ASC")
        else:
            refresh_table(base_query)

    button = Button(window, image=bell_icon, command=notification)
    button.place(x=970, y=10)

    sidebar = Frame(window, bg='#7A6961', width=200, height=600)
    sidebar.pack(side=LEFT, fill=Y)

    Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=dashboard).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=add_animals).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=add_inventory).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=feeding_log).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=scheduling).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=logins).pack(fill=X, pady=10, padx=10)

    main = Frame(window, width=700, height=600, bg='#D9D9D9')
    label = Label(window, text='Add Inventory', font=('Helvetica', 20), bg='#D9D9D9')
    label.pack()

    Label(window, text='Add animal:', font=('Helvetica', 14), bg='#D9D9D9').place(x=200, y=50)
    select_animals = ttk.Combobox(window, values=animal_names, font=('Helvetica', 14))
    select_animals.set("Select Animals:")
    select_animals.place(x=200, y=80)

    Label(window, text='Add Feeds:', font=('Helvetica', 14), bg='#D9D9D9').place(x=200, y=120)
    feed_entry = Entry(window, font=('Helvetica', 14))
    feed_entry.place(x=200, y=150)

    Label(window, text='Feeds KG/LBS:', font=('Helvetica', 14), bg='#D9D9D9').place(x=450, y=50)
    weight_entry = Entry(window, font=('Helvetica', 14))
    weight_entry.place(x=450, y=80)

    Label(window, text='Cost ₱:', font=('Helvetica', 14), bg='#D9D9D9').place(x=700, y=50)
    cost_entry = Entry(window, font=('Helvetica', 14))
    cost_entry.place(x=700, y=80)

    Filter = ["Cost Ascending", "Cost Descending", "A-Z"]
    Label(window, text='Filter Inventory:', font=('Helvetica', 14), bg='#D9D9D9').place(x=200, y=240)
    filter_inventory = ttk.Combobox(window, values=Filter, font=('Helvetica', 14))
    filter_inventory.set("Filter:")
    filter_inventory.place(x=200, y=270)
    filter_inventory.bind("<<ComboboxSelected>>", apply_filter)

    headings = ("Animals", "Feeds", "KILO/LBS", "Cost")
    table = ttk.Treeview(window, columns=headings, show="headings", height=5)
    for col in headings:
        table.heading(col, text=col, anchor='center')
        table.column(col, anchor='center', width=150)
    table.place(x=200, y=300)
    table.bind("<ButtonRelease-1>", on_row_select)

    Button(window, text='Add Inventory', font=('Helvetica', 14), bg='#14AE5C', command=add_entry).place(x=200, y=180)
    Button(window, text='Update', font=('Helvetica', 14), bg='#F9B233', command=update_entry).place(x=350, y=180)
    Button(window, text='Delete', font=('Helvetica', 14), bg='#D93434', command=delete_entry).place(x=450, y=180)

    main.pack()
    refresh_table()

def feeding_log():
    for widget in window.winfo_children():
        widget.destroy()

    db = conn()
    if db is None:
        return
    cursor = db.cursor()
    
    check_low_stock_and_alert(db)

    # Notification Button
    button = Button(window, image=bell_icon, command=notification)
    button.pack(side=RIGHT, anchor='n', pady=10, padx=10)

    # Sidebar
    sidebar = Frame(window, bg='#7A6961', width=200, height=600)
    sidebar.pack(side=LEFT, fill=Y)

    buttons = [
        ('Cost Analysis', dashboard),
        ('Manage \nAnimal Profile', add_animals),
        ('Inventory', add_inventory),
        ('Feeding Log', feeding_log),
        ('Schedule \nFeeding', scheduling),
        ('Logout', logins),
    ]
    for text, cmd in buttons:
        Button(sidebar, text=text, fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=cmd).pack(fill=X, pady=10, padx=10)

    # Main container
    main = Frame(window, width=800, height=600, bg='#D9D9D9')
    main.pack(side=LEFT, fill=BOTH, expand=True)

    Label(main, text='Feeding Log', font=('Helvetica', 20), bg='#D9D9D9').pack(pady=10)

    # Load inventory data
    cursor.execute("""
        SELECT
            inventory.inventory_id,
            animals.animal_id,
            animals.animal_name,
            inventory.feed_name,
            inventory.feed_cost,
            inventory.feed_weight
        FROM inventory
        JOIN animals ON inventory.animal_id = animals.animal_id
    """)


    inventory_rows = cursor.fetchall()

    animals = []
    animal_inventory_map = {}
    for row in inventory_rows:
        inv_id, animal_id, animal_name, feed, cost, weight = row
        animals.append(animal_name)
        animal_inventory_map[animal_name] = {
            'animal_id': animal_id,
            'inventory_id': inv_id,
            'feed_name': feed,
            'feed_cost': cost,
            'feed_weight': weight
        }

    # Input Fields
    Label(main, text='Select Animal:', font=('Helvetica', 14), bg='#D9D9D9').place(x=20, y=60)
    select_animals = ttk.Combobox(main, values=animals, font=('Helvetica', 14))
    select_animals.set("Select Animal:")
    select_animals.place(x=20, y=90)

    Label(main, text='Feeds Type:', font=('Helvetica', 14), bg='#D9D9D9').place(x=300, y=60)
    feed_type_entry = Entry(main, font=('Helvetica', 14))
    feed_type_entry.place(x=300, y=90)

    Label(main, text='Feeds KG/LBS:', font=('Helvetica', 14), bg='#D9D9D9').place(x=20, y=140)
    feed_weight_entry = Entry(main, font=('Helvetica', 14))
    feed_weight_entry.place(x=20, y=170)

    Label(main, text='Feed Cost:', font=('Helvetica', 14), bg='#D9D9D9').place(x=300, y=140)
    feed_cost_entry = Entry(main, font=('Helvetica', 14))
    feed_cost_entry.place(x=300, y=170)

    def on_animal_select(event):
        animal = select_animals.get()
        if animal in animal_inventory_map:
            data = animal_inventory_map[animal]
            feed_type_entry.delete(0, END)
            feed_type_entry.insert(0, data['feed_name'])
            feed_cost_entry.delete(0, END)
            feed_cost_entry.insert(0, data['feed_cost'])
            feed_weight_entry.delete(0, END)
            feed_weight_entry.insert(0, data['feed_weight'])

    select_animals.bind("<<ComboboxSelected>>", on_animal_select)

    def add_feed_log():
        animal = select_animals.get()
        feed_name = feed_type_entry.get()
        weight = feed_weight_entry.get()
        cost = feed_cost_entry.get()

        if animal not in animal_inventory_map:
            messagebox.showerror("Error", "Please select a valid animal.")
            return
        
        animal_id = animal_inventory_map[animal]['animal_id']
        inventory_id = animal_inventory_map[animal]['inventory_id']

        if not all([animal, feed_name, weight, cost]):
            messagebox.showerror("Error", "Please fill in all fields.")
            return

        try:
            weight = float(weight)
            cost = float(cost)
        except ValueError:
            messagebox.showerror("Error", "Feed weight and cost must be numeric.")
            return

        inventory_id = animal_inventory_map[animal]['inventory_id']

        cursor.execute("""
            INSERT INTO feeding_log (feed_name, feed_weight, feed_cost, animal_id, inventory_id)
            VALUES (%s, %s, %s, %s, %s)
        """, (feed_name, weight, cost, animal_id, inventory_id))

        # Deduct feed weight and cost from inventory
        current_weight = animal_inventory_map[animal]['feed_weight']
        current_cost = animal_inventory_map[animal]['feed_cost']

        if current_weight == 0:
            messagebox.showerror("Error", "Inventory feed weight is zero, cannot deduct.")
            return

        cost_per_unit = current_cost / current_weight
        deducted_cost = cost_per_unit * weight

        cursor.execute("""
            UPDATE inventory SET
                feed_weight = feed_weight - %s,
                feed_cost = feed_cost - %s
            WHERE inventory_id = %s
        """, (weight, deducted_cost, inventory_id))


        db.commit()
        messagebox.showinfo("Success", "Feeding log added and inventory updated.")
        feeding_log()

    Button(main, text='Add Feed Log', font=('Helvetica', 14), bg='#14AE5C', command=add_feed_log).place(x=20, y=220)

    # === FILTERING ===
    Label(main, text="Filter Feed Logs:", font=("Helvetica", 14), bg='#D9D9D9').place(x=20, y=280)
    filter_options = ("A-Z", "Ascending", "Descending")
    Filter_logs = ttk.Combobox(main, values=filter_options, font=("Helvetica", 14))
    Filter_logs.set("Filter Logs:")
    Filter_logs.place(x=20, y=310)

    headings = ("Animal", "Feed Type", "KILO/LBS", "Cost")
    table = ttk.Treeview(main, columns=headings, show="headings", height=8)
    for col in headings:
        table.heading(col, text=col)
        table.column(col, anchor='center', width=120)
    table.place(x=300, y=280)

    def filter_logs(event=None):
        option = Filter_logs.get()
        query = """
            SELECT animals.animal_name, feeding_log.feed_name, feeding_log.feed_weight, feeding_log.feed_cost
            FROM feeding_log
            JOIN animals ON feeding_log.animal_id = animals.animal_id
        """
        if option == "A-Z":
            query += " ORDER BY animal_name ASC"
        elif option == "Ascending":
            query += " ORDER BY feed_cost ASC"
        elif option == "Descending":
            query += " ORDER BY feed_cost DESC"
        cursor.execute(query)
        rows = cursor.fetchall()
        table.delete(*table.get_children())
        for row in rows:
            table.insert("", END, values=row)

    Filter_logs.bind("<<ComboboxSelected>>", filter_logs)
    filter_logs()

    # Variable to store selected log row
    selected_row = {"animal": None, "feed_name": "", "weight": "", "cost": ""}

    def on_table_select(event):
        selected = table.focus()
        if not selected:
            return

        values = table.item(selected, "values")
        if values:
            animal, feed_name, weight, cost = values
            select_animals.set(animal)
            feed_type_entry.delete(0, END)
            feed_type_entry.insert(0, feed_name)
            feed_weight_entry.delete(0, END)
            feed_weight_entry.insert(0, weight)
            feed_cost_entry.delete(0, END)
            feed_cost_entry.insert(0, cost)

            selected_row["animal"] = animal
            selected_row["feed_name"] = feed_name
            selected_row["weight"] = weight
            selected_row["cost"] = cost

    table.bind("<<TreeviewSelect>>", on_table_select)

    def update_feed_log():
        animal = select_animals.get()
        feed_name = feed_type_entry.get()
        weight = feed_weight_entry.get()
        cost = feed_cost_entry.get()

        if not selected_row["animal"]:
            messagebox.showerror("Error", "Please select a row to update.")
            return

        if not all([animal, feed_name, weight, cost]):
            messagebox.showerror("Error", "Please fill in all fields.")
            return

        try:
            weight = float(weight)
            cost = float(cost)
        except ValueError:
            messagebox.showerror("Error", "Weight and cost must be numeric.")
            return

        # Identify the row to update using all original values
        cursor.execute("""
            UPDATE feeding_log
            SET feed_name = %s, feed_weight = %s, feed_cost = %s
            WHERE feed_name = %s AND feed_weight = %s AND feed_cost = %s
            AND animal_id = (SELECT animal_id FROM animals WHERE animal_name = %s)
        """, (feed_name, weight, cost,
              selected_row["feed_name"], selected_row["weight"], selected_row["cost"],
              selected_row["animal"]))

        db.commit()
        messagebox.showinfo("Updated", "Feed log updated.")
        feeding_log()
        
    def delete_feed_log():
        if not selected_row["animal"]:
            messagebox.showerror("Error", "Please select a row to delete.")
            return

        confirm = messagebox.askyesno("Confirm", "Are you sure you want to delete this feed log?")
        if not confirm:
            return

        cursor.execute("""
            DELETE FROM feeding_log
            WHERE feed_name = %s AND feed_weight = %s AND feed_cost = %s
            AND animal_id = (SELECT animal_id FROM animals WHERE animal_name = %s)
        """, (
            selected_row["feed_name"],
            selected_row["weight"],
            selected_row["cost"],
            selected_row["animal"]
        ))

        db.commit()
        messagebox.showinfo("Deleted", "Feed log deleted.")
        feeding_log()
        

    Button(main, text='Update Feed Log', font=('Helvetica', 14), bg='#1D84B5', command=update_feed_log).place(x=180, y=220)
    Button(main, text='Delete Feed Log', font=('Helvetica', 14), bg='#D9534F', command=delete_feed_log).place(x=360, y=220)



def scheduling():
    for widget in window.winfo_children():
        widget.destroy()

    db = conn()
    if db is None:
        return
    cursor = db.cursor()

    Button(window, image=bell_icon, command=notification).place(x=970, y=10)

    sidebar = Frame(window, bg='#7A6961', width=200, height=600)
    sidebar.pack(side=LEFT, fill=Y)

    for text, cmd in [
        ('Cost Analysis', dashboard),
        ('Manage \nAnimal Profile', add_animals),
        ('Inventory', add_inventory),
        ('Feeding Log', feeding_log),
        ('Schedule \nFeeding', scheduling),
        ('Logout', logins)
    ]:
        Button(sidebar, text=text, fg='black', bg='#D9D9D9', font=('Helvetica', 14),
               relief=FLAT, command=cmd).pack(fill=X, pady=10, padx=10)

    main = Frame(window, width=700, height=600, bg='#D9D9D9')
    main.pack(side=LEFT, fill=BOTH, expand=True)

    Label(main, text='Feeding Schedule', font=('Helvetica', 20), bg='#D9D9D9').pack(pady=10)

    Label(main, text="Select Animal:", font=("Helvetica", 14), bg='#D9D9D9').place(x=30, y=60)

    # Fetch animals from database
    cursor.execute("SELECT animal_id, animal_name FROM animals")
    animal_data = cursor.fetchall()
    animal_dict = {name: aid for aid, name in animal_data}
    animal_names = list(animal_dict.keys())

    select_animals = ttk.Combobox(main, font=("Helvetica", 14), values=animal_names)
    select_animals.set("Select Animal")
    select_animals.place(x=30, y=90)

    Label(main, text="Feeding Time:", font=("Helvetica", 14), bg='#D9D9D9').place(x=30, y=130)
    time_entry = Entry(main, font=("Helvetica", 14))
    time_entry.place(x=30, y=160)

    selected_schedule_id = StringVar()

    # === Treeview Table ===
    headings = ("Animal", "Time")
    table = ttk.Treeview(main, columns=headings, show="headings", height=8)
    for col in headings:
        table.heading(col, text=col)
        table.column(col, anchor='center', width=120)
    table.place(x=400, y=60)

    def load_schedules():
        table.delete(*table.get_children())
        cursor.execute("""
            SELECT animals.animal_name, schedule.time
            FROM schedule
            JOIN animals ON schedule.animal_name = animals.animal_id
        """)
        for row in cursor.fetchall():
            table.insert("", END, values=row)

    def add_schedule():
        animal_name = select_animals.get()
        time = time_entry.get()
        if animal_name not in animal_dict or not time:
            messagebox.showerror("Error", "Please select valid animal and time.")
            return

        animal_id = animal_dict[animal_name]
        cursor.execute("INSERT INTO schedule (animal_name, time) VALUES (%s, %s)", (animal_id, time))
        db.commit()
        messagebox.showinfo("Success", "Schedule added.")
        load_schedules()
        clear_inputs()

    def select_schedule(event):
        item = table.focus()
        if not item:
            return
        values = table.item(item, 'values')
        select_animals.set(values[0])
        time_entry.delete(0, END)
        time_entry.insert(0, values[1])

    def update_schedule():
        sched_id = selected_schedule_id.get()
        animal_name = select_animals.get()
        time = time_entry.get()
        if not sched_id or animal_name not in animal_dict or not time:
            messagebox.showerror("Error", "Please select a valid schedule to update.")
            return

        animal_id = animal_dict[animal_name]
        cursor.execute("UPDATE schedule SET animal_id=%s, time=%s WHERE sched_id=%s",
                       (animal_id, time, sched_id))
        db.commit()
        messagebox.showinfo("Success", "Schedule updated.")
        load_schedules()
        clear_inputs()

    def delete_schedule():
        sched_id = selected_schedule_id.get()
        if not sched_id:
            messagebox.showerror("Error", "Please select a schedule to delete.")
            return
        if messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this schedule?"):
            cursor.execute("DELETE FROM schedule WHERE sched_id=%s", (sched_id,))
            db.commit()
            messagebox.showinfo("Deleted", "Schedule deleted.")
            load_schedules()
            clear_inputs()

    def clear_inputs():
        select_animals.set("Select Animal")
        time_entry.delete(0, END)
        selected_schedule_id.set("")

    # Buttons
    Button(main, text="Add", font=("Helvetica", 12), bg="#14AE5C", command=add_schedule).place(x=30, y=210)
    Button(main, text="Update", font=("Helvetica", 12), bg="#FFC107", command=update_schedule).place(x=90, y=210)
    Button(main, text="Delete", font=("Helvetica", 12), bg="#DC3545", fg="white", command=delete_schedule).place(x=170, y=210)
    Button(main, text="Clear", font=("Helvetica", 12), bg="#6C757D", fg="white", command=clear_inputs).place(x=250, y=210)

    table.bind("<<TreeviewSelect>>", select_schedule)
    load_schedules()

    
def notification():
    for widget in window.winfo_children():
        widget.destroy()

    db = conn()
    if db is None:
        return
    cursor = db.cursor()
    cursor.execute("SELECT feed_name, feed_weight FROM inventory")
    inventory = cursor.fetchall()
    
    check_low_stock_and_alert(db)

    # Sidebar
    sidebar = Frame(window, bg='#7A6961', width=200, height=600)
    sidebar.pack(side=LEFT, fill=Y)

    Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=dashboard).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=add_animals).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=add_inventory).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=feeding_log).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=scheduling).pack(fill=X, pady=10, padx=10)
    Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Helvetica', 14), relief=FLAT, command=logins).pack(fill=X, pady=10, padx=10)

    main = Frame(window, width=820, height=600, bg='#D9D9D9')
    label = Label(window, text="Notification", font=("Helvetica", 14), bg='#D9D9D9')
    label.pack()

    notif = [
        ("Chicken at 11:30 AM",),
        ("Cow at 1:00 PM",),
        ("Pig at 3:00 PM",),
    ]

    # Add low stock items to notifications table
    for feed_name, weight in inventory:
        if weight < 10:
            notif.append((f"{feed_name} is below 10 KG",))

    table = ttk.Treeview(window, columns=("Notification",), show="headings")
    table.heading("Notification", text="Notification")
    table.column("Notification", anchor="center", width=300)

    for row in notif:
        table.insert("", END, values=row)

    table.pack(pady=150)
    main.pack()

def check_low_stock_and_alert(db):
    cursor = db.cursor()
    query = "SELECT feed_name, feed_weight FROM inventory"
    cursor.execute(query)
    results = cursor.fetchall()

    alerts = []
    for feed_name, weight in results:
        # For this example, we treat 10kg as a critical threshold
        if weight < 10:
            alerts.append(f"{feed_name} is below 10 KG!")

    if alerts:
        messagebox.showwarning("Low Stock Alert", "\n".join(alerts))

window = Tk()
window.geometry("1020x520")
window.title("Mercado GUI")

window.iconbitmap("user.ico")
#icon = PhotoImage(file="c.png")
#window.iconphoto(True,icon)
window.config(background="#D9D9D9")

image_path = 'c.png'
image = Image.open(image_path)
image = image.resize((400,300))
photo = ImageTk.PhotoImage(image)

bell_path = 'bell (1).png'
bell = Image.open(bell_path)
bell = bell.resize((30,30))
bell_icon = ImageTk.PhotoImage(bell)

logins()

window.mainloop()